import os
import json
from pathlib import Path

def ingest_corpus(raw_dir: str="data/raw", processed_dir: str = "data/processed"):
    raw_path = Path(raw_dir)
    processed_path = Path(processed_dir)
    processed_path.mkdir(parents=True, exist_ok= True)

    if not list(raw_path.glob("**/*.md")):
        print(f"No markdown files found in {raw_dir}")
        return

    print("Starting Corpus ingestion and parsing...")
    document_count = 0

    for file_path in raw_path.glob("**/*.md"):
        doc_id = str(file_path.relative_to(raw_path))

        try: 
            with open(file_path, "r", encoding="utf-8") as f:
                content = f.read()
        except UnicodeDecodeError:
            with open(file_path, "r", encoding="latin-1") as f:
                content = f.read()

        cleaned_content = content.replace("\r\n", "\n")

        doc_data = {
            "doc_id" : doc_id,
            "full_text" : cleaned_content,
            "char_length" : len(cleaned_content)
        }

        output_file = processed_path /f"{doc_id.replace('/','_')}.json"
        output_file.parent.mkdir(parents=True, exist_ok= True)

        with open (output_file, "w", encoding="utf-8") as out_f:
            json.dump(doc_data, out_f,ensure_ascii= False, indent=2)

        document_count += 1

    print(f"Successfully ingested an parsed {document_count} documents into '{processed_dir}/'.")
    
    
if __name__ == "__main__":
    ingest_corpus()