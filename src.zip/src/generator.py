import os
from anthropic import Anthropic

class RAGGenerator:
    def __init__(self, model_name: str = "claude-sonnet-4-7"):
        """
        Initializes the Anthropic client for generation. 
        Requires ANTHROPIC_API_KEY environment variable.
        """
        self.client = Anthropic()
        self.model_name = model_name

    def generate_answer(self, query: str, retrieved_chunks: list):
        """
        Formats retrieved chunks into a context block, instructs Claude to answer 
        using only the provided text, and requires inline citations.
        """
        # Format chunks with clear identifiers
        context_str = ""
        for i, chunk in enumerate(retrieved_chunks):
            context_str += f"\n--- [Chunk {i+1}] (Doc: {chunk['doc_id']}) ---\n{chunk['chunk_text']}\n"

        prompt = f"""You are a precise technical documentation assistant. Answer the user's question using ONLY the provided context chunks below. 
If the answer cannot be found in the context, state clearly that you do not know. 
Always cite the chunk numbers (e.g., [Chunk 1]) when stating facts from the text.

CONTEXT CHUNKS:
{context_str}

USER QUESTION:
{query}

ANSWER:"""

        try:
            response = self.client.messages.create(
                model=self.model_name,
                max_tokens=600,
                messages=[{"role": "user", "content": prompt}]
            )
            answer_text = response.content[0].text
            return answer_text
        except Exception as e:
            # Fallback if API key is missing during offline testing,grid dry-runs
            print(f"⚠️ LLM Generation warning: {e}. Returning mock answer.")
            return f"Mock Answer: Unable to contact LLM API. Retrieved {len(retrieved_chunks)} chunks."