import pandas as pd

def report():
    df = pd.read_csv("results_with_ci.csv")
    print("--- RAG EXPERIMENT SUMMARY REPORT ---")
    print(df.to_string(index=False))
    
    best_row = df.loc[df['recall@5'].idxmax()]
    print("\n🏆 Top Performing Configuration:")
    print(f"   - Chunker: {best_row['chunker']}")
    print(f"   - Retriever: {best_row['retriever']}")
    print(f"   - Reranker: {best_row['reranker']}")
    print(f"   - Recall@5: {best_row['recall@5']} (CI: [{best_row['recall@5_ci_low']}, {best_row['recall@5_ci_high']})")
    print(f"   - MRR: {best_row['mrr']} (CI: [{best_row['mrr_ci_low']}, {best_row['mrr_ci_high']})")

if __name__ == "__main__":
    report()