import json
from pathlib import Path
import random
import ollama

def generate_synthetic_eval_set(output_path: str = "eval_set.json", target_count: int = 60):
    random.seed(42)
    processed_dir = Path("data/processed")
    json_files = list(processed_dir.glob("*.json"))
    
    if not json_files:
        print("⚠️ No processed files found!")
        return

    eval_items = []
    seen_questions = set()
    print(f"🤖 Generating deduplicated evaluation set with fixed seed (Target: {target_count} questions)...")
    
    file_pool = json_files * 5
    random.shuffle(file_pool)
    
    for file_path in file_pool:
        if len(eval_items) >= target_count:
            break
            
        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)
            
        doc_id = data["doc_id"]
        text = data["full_text"]
        if len(text) < 400:
            continue
            
        start_idx = random.randint(0, max(0, len(text) - 500))
        end_idx = min(start_idx + 400, len(text))
        snippet = text[start_idx:end_idx]
        
        prompt = f"""Based on the technical documentation snippet below, generate ONE precise technical question that can be answered using this exact text.
Return ONLY a valid JSON object with keys "question" and "type" (where type is either "exact-term" or "conceptual"). No markdown formatting wrappers.

SNIPPET:
{snippet}
"""
        try:
            res = ollama.chat(model="llama3.2", messages=[{"role": "user", "content": prompt}])
            content = res["message"]["content"].strip()
            if content.startswith("```"):
                content = content.split("```")[1]
                if content.startswith("json"):
                    content = content[4:]
            content = content.strip()
            
            parsed = json.loads(content)
            q_text = parsed.get("question", "").strip()
            
            if q_text and q_text not in seen_questions:
                seen_questions.add(q_text)
                eval_items.append({
                    "question": q_text,
                    "type": parsed.get("type", "conceptual"),
                    "gold_doc_id": doc_id,
                    "gold_start": start_idx,
                    "gold_end": end_idx
                })
                print(f"   [+] Generated unique question ({len(eval_items)}/{target_count}) for {doc_id}")
        except Exception as e:
            continue

    with open(output_path, "w", encoding="utf-8") as out_f:
        json.dump(eval_items, out_f, indent=2)
        
    print(f"✅ Successfully generated {len(eval_items)} verified evaluation questions into '{output_path}'!")

if __name__ == "__main__":
    generate_synthetic_eval_set()