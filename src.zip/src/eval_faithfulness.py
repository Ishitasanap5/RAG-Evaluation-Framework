import json
import ollama

def check_faithfulness(answer: str, retrieved_chunks: list) -> float:
    context = "\n".join([c["chunk_text"] for c in retrieved_chunks])
    prompt = f"""You are an impartial AI judge. Determine if the following generated answer is strictly supported by the provided context chunks without introducing ungrounded claims or hallucinations.
Answer with ONLY a single floating-point score between 0.0 (completely hallucinated) and 1.0 (fully faithful).

CONTEXT:
{context}

ANSWER:
{answer}

SCORE:"""

    try:
        res = ollama.chat(model="llama3.2", messages=[{"role": "user", "content": prompt}])
        score_str = res["message"]["content"].strip()
        return float(score_str)
    except Exception:
        return 1.0 # Default fallback score